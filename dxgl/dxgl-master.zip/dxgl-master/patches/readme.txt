These files have already been merged into DXGL, but are provided for reference purposes.

SetCursorPos hack.patch - Copyright (C) 2018 Syahmi Azhar - Merged manually against revision 799.